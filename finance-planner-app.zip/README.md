# 个人计划与理财助手

一款集计划清单管理与消费理财记录为一体的Web应用，支持PWA安装和APK打包。

## 功能特性

- 📝 **计划清单管理**：创建、编辑、删除和完成日常计划任务
- 💰 **理财记录**：记录日常消费支出，支持分类管理
- 📊 **统计分析**：可视化展示消费数据和预算使用情况
- 🎯 **预算管理**：设置月度预算，实时监控支出
- 🎉 **成就系统**：完成任务获得成就，激励持续使用
- 📅 **纪念日/倒计时**：记录重要日子，自动倒计时提醒
- 🌙 **深色模式**：支持浅色和深色主题切换
- 🎨 **个性化主题**：多种颜色方案可选
- ❤️ **动态背景**：爱心粒子动画背景效果
- 📱 **响应式设计**：完美适配桌面和移动设备

## 部署方式

### 1. PWA部署（推荐）

将应用部署到GitHub Pages或任何支持HTTPS的静态网站托管服务：

1. **克隆项目**：
   ```bash
   git clone https://github.com/your-username/finance-planner-app.git
   cd finance-planner-app
   ```

2. **部署到GitHub Pages**：
   - 将项目推送到GitHub仓库
   - 在仓库设置中启用GitHub Pages
   - 访问生成的URL（通常是 `https://your-username.github.io/finance-planner-app/`）

3. **安装到主屏幕**：
   - 在移动设备上访问网站
   - 等待10秒后会出现"安装到主屏幕"提示
   - 点击安装即可将应用添加到主屏幕

### 2. APK打包方式

使用Cordova将Web应用打包为Android APK：

1. **环境准备**：
   ```bash
   npm install -g cordova cordova-res
   ```

2. **配置项目**：
   - 修改 `cordova-finance-app/config.xml` 中的 `content src` 为您的GitHub Pages URL
   - 创建图标和启动图资源

3. **构建APK**：
   ```bash
   cd cordova-finance-app
   cordova platform add android
   cordova build android --release
   ```

4. **签名APK**（可选）：
   ```bash
   keytool -genkey -v -keystore finance-app.keystore -alias finance-app -keyalg RSA -keysize 2048 -validity 10000
   jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore finance-app.keystore platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk finance-app
   ```

## 项目结构

```
finance-planner-app/
├── index.html          # 主应用文件
├── manifest.json       # PWA配置文件
├── manifest.webmanifest # iOS PWA配置文件
├── service-worker.js   # Service Worker实现离线功能
└── README.md           # 项目说明文档

cordova-finance-app/
├── config.xml          # Cordova配置文件
└── package.json        # npm配置文件
```

## PWA特性

- ✅ **可安装**：支持添加到主屏幕
- ✅ **离线访问**：通过Service Worker缓存核心资源
- ✅ **推送通知**：支持后台推送提醒
- ✅ **后台同步**：离线数据自动同步
- ✅ **响应式设计**：适配各种设备尺寸

## 浏览器支持

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 开发说明

### 添加新功能

1. **修改index.html**：添加新的HTML结构和样式
2. **更新JavaScript**：在现有的脚本区域添加新功能逻辑
3. **PWA配置**：如果需要新的PWA功能，更新manifest.json和service-worker.js

### 自定义主题

在index.html的CSS变量中修改颜色：

```css
:root {
  --primary-color: #6366F1;
  --secondary-color: #8B5CF6;
  --accent-color: #EC4899;
  /* 更多颜色变量 */
}
```

## 数据存储

应用使用浏览器的localStorage进行本地数据存储：
- 计划数据：`plans`
- 理财记录：`financeRecords`
- 预算设置：`budget`
- 纪念日数据：`anniversaries`
- 用户设置：`settings`
- 成就数据：`achievements`

## 安全说明

- 所有数据仅存储在本地，不会上传到服务器
- PWA使用HTTPS确保数据传输安全
- 建议定期备份localStorage数据

## 更新日志

### v1.0.0 (2026-02-20)
- ✨ 初始版本发布
- 📝 实现计划清单管理功能
- 💰 实现理财记录功能
- 📊 添加统计分析功能
- 🎯 实现预算管理
- 🎉 添加成就系统
- 📅 实现纪念日/倒计时功能
- 🌙 支持深色模式
- 🎨 添加个性化主题
- ❤️ 添加动态背景效果
- 📱 优化手机版UI
- 📦 支持PWA安装
- 📱 支持APK打包

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request来改进这个项目！

## 联系方式

如有问题或建议，请联系：[your-email@example.com]