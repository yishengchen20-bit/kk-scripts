#!/bin/bash

# 理财助手APK构建脚本
# 使用方法：./build-apk.sh

set -e

echo "🚀 理财助手APK构建脚本"
echo "======================="

# 检查Node.js环境
if ! command -v node &> /dev/null; then
    echo "❌ 错误：未找到Node.js。请先安装Node.js 16.x或更高版本。"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "❌ 错误：未找到npm。请先安装Node.js。"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2)
echo "✅ Node.js版本: $NODE_VERSION"

# 检查Cordova是否安装
if ! command -v cordova &> /dev/null; then
    echo "📦 正在安装Cordova..."
    npm install -g cordova
fi

CORDOVA_VERSION=$(cordova -v)
echo "✅ Cordova版本: $CORDOVA_VERSION"

# 创建资源目录
echo "📁 创建资源目录..."
mkdir -p res/icon/android
mkdir -p res/screen/android

# 下载默认图标（使用占位图标）
echo "🖼️ 下载应用图标..."
curl -s -o res/icon/android/icon-192-xxxhdpi.png "https://img.icons8.com/color/192/000000/trophy.png"
curl -s -o res/icon/android/icon-144-xxhdpi.png "https://img.icons8.com/color/144/000000/trophy.png"
curl -s -o res/icon/android/icon-96-xhdpi.png "https://img.icons8.com/color/96/000000/trophy.png"
curl -s -o res/icon/android/icon-72-hdpi.png "https://img.icons8.com/color/72/000000/trophy.png"
curl -s -o res/icon/android/icon-48-mdpi.png "https://img.icons8.com/color/48/000000/trophy.png"
curl -s -o res/icon/android/icon-36-ldpi.png "https://img.icons8.com/color/36/000000/trophy.png"

# 创建简单的启动图
echo "📱 创建启动图..."
for density in "ldpi" "mdpi" "hdpi" "xhdpi"; do
    # 创建占位启动图
    touch "res/screen/android/screen-${density}-port.png"
    touch "res/screen/android/screen-${density}-land.png"
done

# 检查并添加Android平台
echo "🔍 检查Android平台..."
if [ ! -d "platforms/android" ]; then
    echo "📱 添加Android平台..."
    cordova platform add android
else
    echo "✅ Android平台已存在"
fi

# 安装必要的插件
echo "🔌 安装必要的插件..."
cordova plugin add cordova-plugin-whitelist cordova-plugin-inappbrowser cordova-plugin-splashscreen cordova-plugin-network-information

# 更新配置
echo "⚙️ 更新配置..."
# 确保config.xml中的配置正确
sed -i 's/<content src=".*" \/>/<content src="index.html" \/>/' config.xml

# 清理旧的构建文件
echo "🧹 清理旧的构建文件..."
rm -rf platforms/android/app/build

# 构建APK
echo "🏗️ 开始构建APK..."
echo "⚠️  注意：这可能需要一些时间，请耐心等待..."

# 使用--debug模式构建，避免签名问题
cordova build android --debug

# 检查构建结果
if [ -f "platforms/android/app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "✅ APK构建成功！"
    echo "📁 APK文件位置: platforms/android/app/build/outputs/apk/debug/app-debug.apk"
    
    # 复制到更简单的位置
    cp "platforms/android/app/build/outputs/apk/debug/app-debug.apk" "finance-app-debug.apk"
    echo "📋 已复制到当前目录: finance-app-debug.apk"
    
    echo ""
    echo "🎉 构建完成！"
    echo "📱 您可以通过以下方式安装APK："
    echo "   1. 将finance-app-debug.apk文件复制到您的Android设备"
    echo "   2. 在设备上启用'未知来源应用'权限"
    echo "   3. 点击APK文件进行安装"
    echo ""
    echo "🔧 提示：如果需要发布版本，请使用 --release 参数并进行签名"
    echo "   例如：cordova build android --release"
else
    echo "❌ APK构建失败！"
    echo "📋 错误信息："
    tail -n 50 "platforms/android/cordova/build.log" 2>/dev/null || echo "无法读取构建日志"
    exit 1
fi

echo ""
echo "📝 下一步建议："
echo "   1. 自定义应用图标和启动图（替换res/目录下的文件）"
echo "   2. 修改config.xml中的应用信息"
echo "   3. 更新www/index.html中的APP_URL为您的实际网站地址"
echo "   4. 考虑添加应用签名以生成发布版本"